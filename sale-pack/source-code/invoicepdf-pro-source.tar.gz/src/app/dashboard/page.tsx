"use client";
import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { FileText, DollarSign, Clock, CheckCircle } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

type Stats = { totalInvoices: number; totalRevenue: number; pendingAmount: number; paidAmount: number };

export default function DashboardOverview() {
  const { data: session } = useSession();
  const [stats, setStats] = useState<Stats>({ totalInvoices: 0, totalRevenue: 0, pendingAmount: 0, paidAmount: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => { if (session?.user?.id) loadStats(); }, [session]);
  const loadStats = async () => { try { const res = await fetch("/api/invoices/stats"); if (res.ok) setStats(await res.json()); } catch(err){} finally { setLoading(false); } };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900">Dashboard Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border p-5"><div className="flex items-center gap-2 text-gray-500 mb-2"><FileText className="w-5 h-5" /><span className="text-sm">Total Invoices</span></div><p className="text-2xl font-bold text-gray-900">{stats.totalInvoices}</p></div>
        <div className="bg-white rounded-xl shadow-sm border p-5"><div className="flex items-center gap-2 text-gray-500 mb-2"><DollarSign className="w-5 h-5" /><span className="text-sm">Total Revenue</span></div><p className="text-2xl font-bold text-gray-900">{formatCurrency(stats.totalRevenue)}</p></div>
        <div className="bg-white rounded-xl shadow-sm border p-5"><div className="flex items-center gap-2 text-yellow-500 mb-2"><Clock className="w-5 h-5" /><span className="text-sm">Pending</span></div><p className="text-2xl font-bold text-yellow-600">{formatCurrency(stats.pendingAmount)}</p></div>
        <div className="bg-white rounded-xl shadow-sm border p-5"><div className="flex items-center gap-2 text-green-500 mb-2"><CheckCircle className="w-5 h-5" /><span className="text-sm">Paid</span></div><p className="text-2xl font-bold text-green-600">{formatCurrency(stats.paidAmount)}</p></div>
      </div>
      <div className="bg-white rounded-xl shadow-sm border p-5"><h3 className="font-medium mb-3 text-gray-700">Quick Actions</h3><div className="flex gap-3"><a href="/dashboard/invoices/new" className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition flex items-center gap-2"><FileText className="w-4 h-4" /> Create Invoice</a><a href="/dashboard/clients" className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition flex items-center gap-2">Manage Clients</a></div></div>
    </div>
  );
}

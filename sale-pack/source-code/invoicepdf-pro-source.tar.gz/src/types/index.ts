export type InvoiceStatus = "draft" | "sent" | "paid" | "overdue" | "cancelled";
export type Currency = "USD" | "EUR" | "GBP" | "JPY" | "CAD" | "AUD";
export interface InvoiceItemInput { description: string; quantity: number; unitPrice: number; }
export interface InvoiceInput { clientId: string; invoiceNo: string; status: InvoiceStatus; issueDate: string; dueDate?: string; notes?: string; taxRate: number; discount: number; currency: Currency; items: InvoiceItemInput[]; }
export interface ClientInput { name: string; email?: string; phone?: string; address?: string; city?: string; state?: string; zip?: string; country?: string; }

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
const { hash } = bcrypt;

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");
  const pwd = await hash("demo123456", 12);
  const user = await prisma.user.upsert({ where: { email: "demo@invoicepdf.com" }, update: {}, create: { email: "demo@invoicepdf.com", password: pwd, name: "Demo User" } });
  console.log("User:", user.email);

  const c1 = await prisma.client.create({ data: { name: "Acme Corporation", email: "billing@acme.com", address: "123 Business Avenue", city: "New York", state: "NY", zip: "10001", country: "United States", userId: user.id } });
  const c2 = await prisma.client.create({ data: { name: "TechStart GmbH", email: "finance@techstart.de", address: "Berliner Str. 45", city: "Berlin", zip: "10115", country: "Germany", userId: user.id } });
  const c3 = await prisma.client.create({ data: { name: "Creative Agency Ltd", email: "accounts@creative.co.uk", city: "London", country: "United Kingdom", userId: user.id } });
  console.log("3 clients");

  await prisma.invoice.create({ data: { invoiceNo: "INV-0001", status: "paid", issueDate: new Date("2024-01-15"), dueDate: new Date("2024-02-15"), taxRate: 10, discount: 0, currency: "USD", notes: "Payment received via bank transfer.", clientId: c1.id, userId: user.id, items: { create: [{ description: "Website Development", quantity: 1, unitPrice: 2500 }, { description: "UI/UX Design", quantity: 40, unitPrice: 75 }, { description: "Project Management", quantity: 10, unitPrice: 100 }] } } });
  await prisma.invoice.create({ data: { invoiceNo: "INV-0002", status: "sent", issueDate: new Date("2024-03-01"), dueDate: new Date("2024-04-01"), taxRate: 19, discount: 100, currency: "EUR", notes: "19% VAT included.", clientId: c2.id, userId: user.id, items: { create: [{ description: "API Integration", quantity: 1, unitPrice: 1800 }, { description: "Testing & QA", quantity: 20, unitPrice: 60 }] } } });
  await prisma.invoice.create({ data: { invoiceNo: "INV-0003", status: "draft", issueDate: new Date("2024-04-10"), taxRate: 20, discount: 0, currency: "GBP", clientId: c3.id, userId: user.id, items: { create: [{ description: "Brand Identity Package", quantity: 1, unitPrice: 3500 }, { description: "Social Media Campaign", quantity: 1, unitPrice: 1200 }] } } });
  console.log("3 invoices. Seed complete!");
  console.log("Login: demo@invoicepdf.com / demo123456");
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
